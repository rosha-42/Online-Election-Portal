# from django.contrib import admin
from django.contrib import admin
# from .models import Voters
#
# admin.site.register(Voters)
# Register your models here.
